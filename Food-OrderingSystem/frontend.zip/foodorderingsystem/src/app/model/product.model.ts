
export class Products 
{
    pid?: any;
    product_name?: string;
    price?: any;
 
}
