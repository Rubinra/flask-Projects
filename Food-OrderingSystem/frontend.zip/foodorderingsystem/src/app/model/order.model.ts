
export class Order
{
    oid?: any;
    quantity?: number;
    pid?: any;
    total_price?: any;
 
}